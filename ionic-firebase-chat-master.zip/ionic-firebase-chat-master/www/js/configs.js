angular.module('Chat.configs', [])

.constant("CONFIG", {
  // "FIREBASE_URL": 'https://ionic-real-chat.firebaseio.com'
  "FIREBASE_URL": 'https://ionic-firebase-df931.firebaseio.com'
});
