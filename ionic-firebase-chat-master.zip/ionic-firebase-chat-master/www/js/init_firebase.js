var firebaseConfig = {
  apiKey: "AIzaSyBoctx81fu4I8r_q5wndopfE1Mohxv4eWw",
  authDomain: "ionic-firebase-df931.firebaseapp.com",
  databaseURL: "https://ionic-firebase-df931.firebaseio.com",
  projectId: "ionic-firebase-df931",
  storageBucket: "",
  messagingSenderId: "1030296434714"
};


firebase.initializeApp(firebaseConfig);
